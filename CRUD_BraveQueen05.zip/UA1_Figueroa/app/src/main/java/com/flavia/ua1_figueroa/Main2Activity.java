package com.flavia.ua1_figueroa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    EditText txtpin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txtpin=findViewById(R.id.txtpin);
    }

    private void Validar(){
        String pin=txtpin.getText().toString();
        if (pin.equals("2020")){
            startActivity(new Intent(Main2Activity.this,Main3Activity.class));
        }else
            Toast.makeText(this, "ERROR DE AUTENTICACIÓN", Toast.LENGTH_SHORT).show();
    }

    public void onClick(View view){
        Validar();
    }
}
