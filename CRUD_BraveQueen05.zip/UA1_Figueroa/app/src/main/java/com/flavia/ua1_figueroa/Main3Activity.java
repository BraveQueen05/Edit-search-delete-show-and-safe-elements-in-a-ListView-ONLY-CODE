package com.flavia.ua1_figueroa;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {
    EditText txtpais,txtreemplazar;
    ListView listaPaises;
    ArrayList<String>Paises=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        txtpais=findViewById(R.id.txtpais);
        listaPaises=findViewById(R.id.LvPaises);
        txtreemplazar=findViewById(R.id.txtreemplazar);
    }

    public void onClick(View btn){
        String pais =String.valueOf(txtpais.getText().toString());
        String reemplazar;
        ListAdapter listAdapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,Paises);

        int z= Paises.indexOf(pais);

        switch (btn.getId()){
            case R.id.btnAgregar:
                if (pais.equals("")){
                    Toast.makeText(this, "No se ha ingresado ningun país", Toast.LENGTH_SHORT).show();
                }else {
                    Paises.add(pais);
                    listaPaises.setAdapter(listAdapter);
                }
                txtpais.setText("");
                break;
            case R.id.btnEliminar:
                Paises.remove(z);
                listaPaises.setAdapter(listAdapter);
                break;
            case R.id.btnBuscaryReemplazar:
                ArrayList<String> listaFiltrada=new ArrayList<>();
                listaFiltrada.clear();
                for (int i=0;i<Paises.size();i++){
                    if (Paises.get(z)==Paises.get(i))
                        listaFiltrada.add(Paises.get(z));
                }
                ListAdapter listAdapterF=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,listaFiltrada);
                listaPaises.setAdapter(listAdapterF);

                if (!txtreemplazar.getText().toString().isEmpty()){
                    reemplazar=String.valueOf(txtreemplazar.getText().toString());
                    listaFiltrada.set(Paises.indexOf(pais), reemplazar);
                    Paises.set(Paises.indexOf(pais), reemplazar);
                    txtreemplazar.setText("");
                }
                break;
            case R.id.btnMostrar:
                listaPaises.setAdapter(listAdapter);
                break;
        }
    }
}