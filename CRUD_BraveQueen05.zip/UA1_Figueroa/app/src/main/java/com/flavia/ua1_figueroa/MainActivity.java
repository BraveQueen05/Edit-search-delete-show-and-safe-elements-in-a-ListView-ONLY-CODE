package com.flavia.ua1_figueroa;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText txtemail, txtpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtemail=findViewById(R.id.txtemail);
        txtpass=findViewById(R.id.txtpass);
    }

    private void Validacion(){
        String email=txtemail.getText().toString();
        String pass=txtpass.getText().toString();
        if ((email.equals("ua1@hotmail.com"))&&(pass.equals("123"))){
            startActivity(new Intent(MainActivity.this, Main2Activity.class));
        }else{
            Toast.makeText(this, "ERROR DE AUTENTICACIÓN", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClick(View view){
        Validacion();
    }
}
